
<div class="page-header page-header-small">
  <div class="page-header-image" data-parallax="true" style='background-image: url("<?php echo base_url() ?>/assets/img/fileuser/conveyorpage.jpg");'>
  </div>
  <div class="content-center">
    <div class="container">
      <h2 class="title"><strong>Conveyor</strong></h2>
    </div>
  </div>
</div>
<div class="section section-about-us">
      <div class="container">
        <div class="row">
          <div class="col-md-8 ml-auto mr-auto">
            <h2 class="title text-center">Conveyor system</h2>
            <h5 class="description text-justify">
              At Fajar Baru, we engineer technology that guides automated solutions. Our products are designed to transport your product from line to line in an automated and manual assembly process. The New Dawn Conveyor is designed to move products to the right location, at the right time and at the right position needed for the next phase of the production line. This highly accurate product control allows the New Dawn conveyor to be easily integrated with robots, workers and equipment.<br>
              We have helped our customers fulfill orders with accuracy and timely delivery. Whether you are delivering individual products, full casings, or pallets, we can recommend the appropriate equipment, technology and material flow layout. Our engineering team designs conveyor systems using 3D modeling tools, allowing you to visualize and simulate how your final system will operate
            </h5>
          </div>
        </div>
        <div class="separator separator-primary"></div>
        <div class="section-story-overview">
          <div class="row">
          <div class="col-md-6 ml-auto mr-auto">
            <h4 class="title text-center" style="margin-left:-28px;">Conveyor processing</h4>
            <div class="nav-align-center">
              <ul class="nav nav-pills nav-pills-primary nav-pills-just-icons" role="tablist">
                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#raw" role="tablist">
                    <i class="now-ui-icons design-2_ruler-pencil"></i><span style="color:#012B72"> Materials</span>
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link active" data-toggle="tab" href="#install" role="tablist">
                    <i class="now-ui-icons ui-2_settings-90"></i><span style="color:#012B72">Installation</span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <!-- Tab panes -->
          <div class="tab-content gallery">
            <div class="tab-pane active" id="install" role="tabpanel">
              <div class="col-md-10 ml-auto mr-auto">
                <div class="row collections">
                  <div class="col-md-6">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG4168.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG4169.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG4170.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG4171.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG4172.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG4176.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG4185.jpg" alt="" class="img-raised">
                  </div>
                  <div class="col-md-6">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG4177.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG4178.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG4179.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG4180.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG4182.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG4183.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG4184.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG4186.jpg" alt="" class="img-raised">
                  </div>
                </div>
              </div>
            </div>
            <div class="tab-pane" id="raw" role="tabpanel">
              <div class="col-md-10 ml-auto mr-auto">
                <div class="row collections">
                  <div class="col-md-6">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG3195.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG3196.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG3197.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG3198.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG3199.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG3200.jpg" alt="" class="img-raised">
                  </div>
                  <div class="col-md-6">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG3201.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG3202.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG3203.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG3204.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG3205.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-Teh/CIMG3206.jpg" alt="" class="img-raised">
                  </div>
                </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>
      </div>
    </div>

    