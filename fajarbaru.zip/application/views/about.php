
<div class="page-header page-header-small">
  <div class="page-header-image" data-parallax="true" style='background-image: url("<?php echo base_url() ?>/assets/img/fileuser/about.jpg");'>
  </div>
  <div class="content-center">
    <div class="container">
      <h2 class="title"><strong>About Us</strong></h2>
    </div>
  </div>
</div>


<div class="container about">
 <section>
      <header class="text-center">
        <h1>About Us</h1>
      </header>
        <p> Welcome to <strong> FAJAR BARU MAKMUR TEKNIK </strong>, a leading supplier of conveyor, tank, formulation, mixing and liquid processing equipment, and customize systems. Have you ever visited us before, or this is your first time, you will find doing business with us summarized in one word: <strong> Simple. </strong> </p>
        <p> From finding out what your application requests to getting your product in your hands quickly, we are an CREATIVE manufacturer of the industry that constantly strives to make the whole process simple. We understand that our customers coordinate a large number of projects and we are eager to help them solve their needs simply and effectively. </p>
        <p> <strong> Why do our customers trust FAJAR BARU MAKMUR TEKNIK? </strong> </p>
        <p> <strong> Options </strong>: We have one of the biggest product offerings in the Industry world. <br> <strong> Convenience </strong>: We can send almost all of our Products to you in just a few days. <br> <strong> Quality </strong>: Each Product goes through a final acceptance test before leaving our facility, and our manufacturers and industry experts are ready to help you to ensure your complete satisfaction with each product. </p>
        <p> <strong> Customer Experience </strong>: Your experience is our top priority. & nbsp; We want you to be 100% satisfied not only with the product, but from initial contact with FAJAR BARU MAKMUR TEKNIK to final delivery. </p>
  </section>
</div>