
<div class="page-header page-header-small">
  <div class="page-header-image" data-parallax="true" style='background-image: url("<?php echo base_url() ?>/assets/img/fileuser/formulasi.jpg");'>
  </div>
  <div class="content-center">
    <div class="container">
      <h2 class="title"><strong>Formulasi</strong></h2>
    </div>
  </div>
</div>
<div class="section section-about-us">
      <div class="container">
        <div class="row">
          <div class="col-md-8 ml-auto mr-auto">
            <h2 class="title text-center">Formulasi</h2>
            <h5 class="description text-justify">
              Whether you’re building out a new chemical plant or testing a new process, you want to make sure you are doing business with a company that knows chemical processing and engineering. We have a long history in the chemical industry and understand the unique challenges in chemical stirrers and liquid processing equipment. Knowing how materials work together is important and often times does not leave much room for error.<br>
              With us you will get precise engineering coupled with expertise and understanding to deliver high quality and safe industrial chemical mixers. Contact us for more information on our liquid processing equipment and chemical mixer machines.
            </h5>
          </div>
        </div>
        <div class="separator separator-primary"></div>
        <div class="section-story-overview">
          <div class="row">
          <div class="col-md-6 ml-auto mr-auto">
            <h4 class="title text-center" style="margin-left: -20px;">Formulasi Industry</h4>
            <div class="nav-align-center">
              <ul class="nav nav-pills nav-pills-primary nav-pills-just-icons" role="tablist">
                <li class="nav-item">
                  <a class="nav-link active" data-toggle="tab" href="#install" role="tablist">
                    <i class="now-ui-icons ui-2_settings-90"></i><span style="color:#012B72">Chemical</span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <!-- Tab panes -->
          <div class="tab-content gallery">
            <div class="tab-pane active" id="install" role="tabpanel">
              <div class="col-md-10 ml-auto mr-auto">
                <div class="row collections">
                  <div class="col-md-6">
                    <img src="<?php echo base_url() ?>/assets/img/Formulasi/IMG_0946.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Formulasi/IMG_0950.jpg" alt="" class="img-raised">
                  </div>
                  <div class="col-md-6">
                    <img src="<?php echo base_url() ?>/assets/img/Formulasi/IMG_0947.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Formulasi/IMG_0953.jpg" alt="" class="img-raised">
                  </div>
                </div>
              </div>
            </div>
            </div>
          </div>
        </div>
        </div>
      </div>
    </div>