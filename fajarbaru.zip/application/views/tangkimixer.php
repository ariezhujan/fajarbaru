
<div class="page-header page-header-small">
  <div class="page-header-image" data-parallax="true" style='background-image: url("<?php echo base_url() ?>/assets/img/fileuser/mixer.jpg");'>
  </div>
  <div class="content-center">
    <div class="container">
      <h2 class="title"><strong>Tangki & Mixer</strong></h2>
    </div>
  </div>
</div>
<div class="section section-about-us">
      <div class="container">
        <div class="row">
          <div class="col-md-8 ml-auto mr-auto">
            <h2 class="title text-center">Tangki & Mixer</h2>
            <h5 class="description text-justify">
              Welcome to Fajar Baru Teknik, the leading Customize of liquid processing and mixing equipment. Have you ever visited us before, or this is your first time, you will find doing business with us summarized in one word: Simple.From finding out what your application requests to get your product in your hands quickly, we are an industrial mixer manufacturer that continually strives to make the whole process simple. We understand that our customers coordinate a large number of projects and we want to help them solve their mixing needs simply and effectively.Why do customers trust us? <br>
              <b>Option :</b> We have one of the largest product offerings in the world of chemical agitation.
              Convenience: We can send almost all of our mixers to you in just a few days.<br>
              <b>Quality :</b> Each mixer undergoes final acceptance testing before leaving our facility, and our industrial mixer manufacturers and experts are ready to help you to ensure your complete satisfaction with each product.
              Customer Experience: Your experience is our top priority. We want you to be 100% satisfied not only with the product, but from the initial contact with Mixer Direct to the final delivery.
            </h5>
          </div>
        </div>
        <div class="separator separator-primary"></div>
        <div class="section-story-overview">
          <div class="row">
          <div class="col-md-6 ml-auto mr-auto">
            <h4 class="title text-center" style="margin-left:-20px">Processing</h4>
            <div class="nav-align-center">
              <ul class="nav nav-pills nav-pills-primary nav-pills-just-icons" role="tablist">
                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#raw" role="tablist">
                    <i class="now-ui-icons design-2_ruler-pencil"></i><span style="color:#012B72"> Tangki</span>
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link active" data-toggle="tab" href="#install" role="tablist">
                    <i class="now-ui-icons ui-2_settings-90"></i><span style="color:#012B72">Mixer</span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <!-- Tab panes -->
          <div class="tab-content gallery">
            <div class="tab-pane active" id="install" role="tabpanel">
              <div class="col-md-10 ml-auto mr-auto">
                <div class="row collections">
                  <div class="col-md-6">
                    <img src="<?php echo base_url() ?>/assets/img/Kneader Mixer/IMG_0358.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Kneader Mixer/SAM_0105.jpg" alt="" class="img-raised">
                  </div>
                  <div class="col-md-6">
                    <img src="<?php echo base_url() ?>/assets/img/Kneader Mixer/IMG_1090.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Kneader Mixer/SAM_0108.jpg" alt="" class="img-raised">
                  </div>
                  <div class="col-md-6">
                    <img src="<?php echo base_url() ?>/assets/img/Homogenizer RISTRA/DSCN2941.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Homogenizer RISTRA/DSCN2943.jpg" alt="" class="img-raised">
                  </div>
                  <div class="col-md-6">
                    <img src="<?php echo base_url() ?>/assets/img/Homogenizer RISTRA/CIMG0453.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Homogenizer RISTRA/CIMG2061.jpg" alt="" class="img-raised">
                  </div>
                </div>
              </div>
            </div>
            <div class="tab-pane" id="raw" role="tabpanel">
              <div class="col-md-10 ml-auto mr-auto">
                <div class="row collections">
                  <div class="col-md-6">
                    <img src="<?php echo base_url() ?>/assets/img/Double Paddle/P9120387.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Double Paddle/P7110171.jpg" alt="" class="img-raised">
                  </div>
                  <div class="col-md-6">
                    <img src="<?php echo base_url() ?>/assets/img/Double Paddle/P8130227.jpg" alt="" class="img-raised">
                    <img src="<?php echo base_url() ?>/assets/img/Double Paddle/P9060287.jpg" alt="" class="img-raised">
                  </div>
                </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>
      </div>
    </div>