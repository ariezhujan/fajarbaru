
<!DOCTYPE html>
<html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
  
  <link rel="apple-touch-icon" sizes="76x76" href="<?php echo base_url() ?>/assets/img/fileuser/logofajar.png">
  <link rel="icon" type="image/png" href="<?php echo base_url() ?>/assets/img/fileuser/logofajar.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
   Fajar Baru Teknik Makmur
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <meta name="robots" content="index, follow">
  <meta name="subject" content="Fajar Baru, Conveyor, Tank & Mixer, Formulation System, And Customize">
  <meta name="metatag" content="Fajar Baru Teknik Makmur">
  <meta name="keywords" content="Fajar Baru, Conveyor, Tank & Mixer, Formulation System, And Customize">
  <meta name="description" content="Fajar Baru, Conveyor, Tank & Mixer, Formulation System, And Customize">
  <meta property="og:title" content="Fajar Baru Teknik Makmur" />
  <meta property="og:url" content="https://fajarbaru.skyglobalutama.com/home" />
  <meta property="og:image" content="<?php echo base_url() ?>/assets/img/fileuser/logofajar.png" />
  <meta property="og:image:type" content="image/png" />
  <meta property="og:description" content="OPTIMAL SOLUTION FOR EVERY MATERIAL HANDLING APPLICATION" />
  <meta property="og:site_name" content="Fajar Baru Teknik Makmur" />
  <meta property="og:type" content="article" />
  <meta property="og:image:width" content="648" />
  <meta property="og:image:height" content="468" />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  <!-- CSS Files -->
  <link href="<?php echo base_url() ?>/assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="<?php echo base_url() ?>/assets/css/now-ui-kit.css?v=1.3.0" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="<?php echo base_url() ?>/assets/css/style.css" rel="stylesheet" />
</head>

<body class="landing-page sidebar-collapse">
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg bg-primary fixed-top navbar-transparent " color-on-scroll="400">
    <div class="container">
    	<div class="navbar-translate">
        <a class="navbar-brand" href="#" rel="tooltip" title="" data-placement="bottom" target="_blank" data-original-title="Teknologi Inovatif dan Konsultatif">
          <img src="<?php echo base_url('assets/img/fileuser/logofajar.png'); ?>" alt="">&nbsp;<p>Fajar Baru Teknik Makmur</p>
        </a>
      </div>
      <div class="navbar-translate">
        <a class="navbar-brand" href="<?php echo base_url('home') ?>" rel="tooltip">
        </a>
        <button class="navbar-toggler navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-bar top-bar"></span>
          <span class="navbar-toggler-bar middle-bar"></span>
          <span class="navbar-toggler-bar bottom-bar"></span>
        </button>
      </div>
      <div class="collapse navbar-collapse justify-content-end" id="navigation" data-nav-image="<?php echo base_url() ?>/assets/img/fileuser/blurred-image-1.jpg">
        <ul class="navbar-nav">
          <li class="nav-item  <?php if($this->uri->segment(1) == "home"){echo "active";} ?>">
            <a class="nav-link" href="<?php echo base_url('home') ?>">Home</a>
          </li>
          <li class="nav-item dropdown <?php if(($this->uri->segment(1) == "conveyor") OR ($this->uri->segment(1) == "tangkimixer") OR ($this->uri->segment(1) == "formulasi")){echo "active";} ?>">
            <a href="#" class="nav-link dropdown-toggle" id="navbarDropdownMenuLink1" data-toggle="dropdown" aria-expanded="false">
              <i class="now-ui-icons design_app"></i>
              <p>Product</p>
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink1">
              <a class="dropdown-item <?php if($this->uri->segment(1) == "conveyor"){echo "active";} ?>" href="<?php echo base_url('conveyor') ?>">
                <div class="text-primary"><i class="now-ui-icons objects_spaceship"></i></i></div> Conveyor system 
              </a>
              <a class="dropdown-item <?php if($this->uri->segment(1) == "tangkimixer"){echo "active";} ?>" href="<?php echo base_url('tangkimixer') ?>">
                <div class="text-primary"><i class="now-ui-icons shopping_box"></i></i></div> Tangki & Mixer
              </a>
              <a class="dropdown-item <?php if($this->uri->segment(1) == "formulasi"){echo "active";} ?>" href="<?php echo base_url('formulasi') ?>">
                <div class="text-primary"><i class="now-ui-icons business_bulb-63"></i></div> Formulasi system
              </a>
              <a class="dropdown-item" href="">
                <div class="text-primary"><i class="now-ui-icons design-2_ruler-pencil"></i></i></div> Customized system
              </a>
            </div>
          </li>
          <li class="nav-item <?php if($this->uri->segment(1) == "service"){echo "active";} ?>">
            <a class="nav-link" href="<?php echo base_url('service') ?>">Service</a>
          </li>
          <li class="nav-item <?php if($this->uri->segment(1) == "about"){echo "active";} ?>">
            <a class="nav-link" href="<?php echo base_url('about') ?>">About Us</a>
          </li>
          <li class="nav-item <?php if($this->uri->segment(1) == "contact"){echo "active";} ?>">
            <a class="nav-link" href="<?php echo base_url('contact') ?>">Contact us</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" rel="tooltip" title="Contact us on Phone" data-placement="bottom" href="tel:02130042058">
              <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
                width="20" height="20"
                viewBox="0 0 172 172"
                style=" fill:#000000;"><g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><path d="M0,172v-172h172v172z" fill="none"></path><g fill="#ffffff"><path d="M112.875,106.425l-18.20333,18.13167c-10.97933,-5.7835 -19.77283,-12.52017 -27.219,-20.00933c-7.48917,-7.44617 -14.22583,-16.23967 -20.00933,-27.219l18.13167,-18.20333l-4.57233,-37.625h-39.50267c0,0 0,2.35067 0,7.16667c0,32.5295 13.18667,63.597 35.58967,86.24367c22.64667,22.403 53.71417,35.58967 86.24367,35.58967c4.816,0 7.16667,0 7.16667,0v-39.50267z"></path></g></g>
              </svg>
              <p class="d-lg-none d-xl-none">Phone</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" rel="tooltip" title="Chat us on Whatsapp" data-placement="bottom" href="https://wa.me/6281803014077">
              <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
                width="20" height="20"
                viewBox="0 0 172 172"
                style=" fill:#000000;"><g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><path d="M0,172v-172h172v172z" fill="none"></path><g fill="#ffffff"><path d="M136.7185,35.31733c-13.51633,-13.5235 -31.49033,-20.97683 -50.63967,-20.984c-39.45967,0 -71.5735,32.0995 -71.58783,71.55917c-0.00717,12.61333 3.2895,24.92567 9.55317,35.776l-9.71083,35.99817l37.50317,-8.86517c10.45617,5.70467 22.22383,8.7075 34.2065,8.71467h0.02867c39.4525,0 71.56633,-32.10667 71.58783,-71.55917c0.01433,-19.12783 -7.42467,-37.109 -20.941,-50.63967zM121.10233,111.47033c-1.49067,4.17817 -8.7935,8.20583 -12.07583,8.49967c-3.28233,0.301 -6.35683,1.4835 -21.46417,-4.472c-18.18183,-7.16667 -29.66283,-25.80717 -30.5515,-26.99683c-0.89583,-1.19683 -7.30283,-9.6965 -7.30283,-18.49717c0,-8.80067 4.6225,-13.12933 6.26367,-14.91383c1.64117,-1.79167 3.57617,-2.236 4.773,-2.236c1.18967,0 2.3865,0 3.42567,0.043c1.27567,0.05017 2.6875,0.11467 4.02767,3.08883c1.591,3.54033 5.06683,12.384 5.51117,13.27983c0.44433,0.89583 0.74533,1.94217 0.1505,3.13183c-0.59483,1.18967 -0.89583,1.935 -1.7845,2.98133c-0.89583,1.04633 -1.87767,2.32917 -2.68033,3.13183c-0.89583,0.88867 -1.8275,1.86333 -0.78833,3.64783c1.04633,1.79167 4.62967,7.64683 9.94733,12.384c6.837,6.09167 12.59183,7.9765 14.3835,8.8795c1.79167,0.89583 2.83083,0.74533 3.87717,-0.4515c1.04633,-1.18967 4.472,-5.21733 5.66167,-7.009c1.18967,-1.79167 2.3865,-1.49067 4.02767,-0.89583c1.64117,0.59483 10.43467,4.9235 12.21917,5.81933c1.79167,0.89583 2.98133,1.34017 3.42567,2.0855c0.44433,0.73817 0.44433,4.3215 -1.04633,8.49967z"></path></g></g>
              </svg>
              <p class="d-lg-none d-xl-none">Whatsapp</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" rel="tooltip" title="Massage us on E-Mail" data-placement="bottom" href="mailto: info@fabatech.net?subject=Question From Web">
              <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
                width="20" height="20"
                viewBox="0 0 172 172"
                style=" fill:#000000;"><g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><path d="M0,172v-172h172v172z" fill="none"></path><g fill="#ffffff"><path d="M28.66667,28.66667c-7.33867,0 -13.32686,5.53715 -14.16536,12.65365l71.4987,44.67969l71.49869,-44.67969c-0.83849,-7.1165 -6.82669,-12.65365 -14.16536,-12.65365zM14.33333,55.55566v73.44434c0,7.91917 6.41417,14.33333 14.33333,14.33333h87.23177l-18.53255,-18.53256c-2.6875,-2.6875 -4.19922,-6.33578 -4.19922,-10.13411v-18.8125l-3.37337,2.11361c-2.322,1.45483 -5.26459,1.45483 -7.58659,0zM157.66667,55.55566l-48.72493,30.44434h12.8916c3.79833,0 7.44661,1.51172 10.13411,4.19922l25.69922,25.69922zM107.5,100.33333v14.33333l36.88314,36.88314l14.33333,-14.33333l-36.88314,-36.88314zM163.78353,142.28353l-14.33333,14.33333l7.16667,7.16667c1.3975,1.3975 3.66239,1.3975 5.06706,0l9.26628,-9.26628c1.3975,-1.3975 1.3975,-3.66956 0,-5.06706z"></path></g></g>
              </svg>
              <p class="d-lg-none d-xl-none">Mail</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- End Navbar -->
  <div class="wrapper">
    <div class="content"><!--Start Content Template-->
      <?php $this->load->view($content); ?>
    </div><!--End Content Template-->

        <!-- Footer -->


    <footer class="footer footer-default">
      <div class=" container-fluid ">
        <div class="copyright" id="copyright">
          &copy;
          <script>
            document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))
          </script> FAJAR BARU TEKNIK MAKMUR

        </div>
      </div>
    </footer>
  </div>
  <!--   Core JS Files   -->
  <script src="<?php echo base_url() ?>/assets/js/core/jquery.min.js" type="text/javascript"></script>
  <script src="<?php echo base_url() ?>/assets/js/core/popper.min.js" type="text/javascript"></script>
  <script src="<?php echo base_url() ?>/assets/js/core/bootstrap.min.js" type="text/javascript"></script>
  <!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
  <script src="<?php echo base_url() ?>/assets/js/plugins/bootstrap-switch.js"></script>
  <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
  <script src="<?php echo base_url() ?>/assets/js/plugins/nouislider.min.js" type="text/javascript"></script>
  <!--  Plugin for the DatePicker, full documentation here: https://github.com/uxsolutions/bootstrap-datepicker -->
  <script src="<?php echo base_url() ?>/assets/js/plugins/bootstrap-datepicker.js" type="text/javascript"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Control Center for Now Ui Kit: parallax effects, scripts for the example pages etc -->
  <script src="<?php echo base_url() ?>/assets/js/now-ui-kit.js?v=1.3.0" type="text/javascript"></script>
</body>

</html>