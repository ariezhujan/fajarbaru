<div class="page-header page-header-small">
  <div class="page-header-image" data-parallax="true" style='background-image: url("<?php echo base_url() ?>/assets/img/fileuser/conveyor1.jpg");'>
  </div>
  <div class="content-center">
    <div class="container">
      <h2 class="title"><strong>Optimal solution for every material handling application</strong></h2>
      <div class="text-center">
        <a class="btn btn-primary" >
          <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
            width="50" height="50"
            viewBox="0 0 172 172"
            style=" fill:#000000;"><g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><path d="M0,172v-172h172v172z" fill="none"></path><g fill="#ffffff"><path d="M44.72,17.2c-5.6587,0 -10.32,4.6613 -10.32,10.32v3.93047c-5.91738,1.53883 -10.32,6.8765 -10.32,13.26953v17.2h20.64v6.88h-20.64v21.84265c-8.00488,2.84144 -13.76,10.46927 -13.76,19.43735c0,8.96808 5.75512,16.59591 13.76,19.43735v18.40265h-20.64v6.88h158.24h6.88v-3.44v-3.44h-10.32v-65.36h-3.66172l-3.44,-51.6h-13.53828l-2.98313,44.72h9.86313v6.88h-65.36v-55.04c0,-5.6587 -4.6613,-10.32 -10.32,-10.32zM44.72,24.08h24.08c1.9437,0 3.44,1.4963 3.44,3.44v55.04h-13.76v65.36h-6.88v-103.2c0,-6.39303 -4.40262,-11.7307 -10.32,-13.26953v-3.93047c0,-1.9437 1.4963,-3.44 3.44,-3.44zM30.96,96.32c7.58864,0 13.76,6.17136 13.76,13.76c0,7.58864 -6.17136,13.76 -13.76,13.76c-7.58864,0 -13.76,-6.17136 -13.76,-13.76c0,-7.58864 6.17136,-13.76 13.76,-13.76zM68.8,96.32h13.76v6.88h-13.76zM89.44,96.32h13.76v6.88h-13.76zM113.52,96.32h13.76v6.88h-13.76zM134.16,96.32h13.76v6.88h-13.76zM68.8,113.52h13.76v6.88h-13.76zM89.44,113.52h13.76v6.88h-13.76zM113.52,113.52h13.76v6.88h-13.76zM134.16,113.52h13.76v6.88h-13.76z"></path></g></g></svg>
        </a>
        <a class="btn btn-primary">
          <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
            width="50" height="50"
            viewBox="0 0 172 172"
            style=" fill:#000000;"><g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><path d="M0,172v-172h172v172z" fill="none"></path><g fill="#ffffff"><g id="surface1"><path d="M30.96,0c-3.78937,0 -6.88,3.09063 -6.88,6.88v89.44c0,3.78938 3.09063,6.88 6.88,6.88h123.84c3.78938,0 6.88,-3.09062 6.88,-6.88v-89.44c0,-3.78937 -3.09062,-6.88 -6.88,-6.88zM73.96,17.2h37.84c2.84875,0 5.16,2.31125 5.16,5.16c0,2.84875 -2.31125,5.16 -5.16,5.16h-37.84c-2.84875,0 -5.16,-2.31125 -5.16,-5.16c0,-2.84875 2.31125,-5.16 5.16,-5.16zM30.96,110.08c-17.06562,0 -30.96,13.88094 -30.96,30.96c0,17.07906 13.89438,30.96 30.96,30.96h141.04v-30.96c0,9.48688 -7.71312,17.2 -17.2,17.2c-9.48687,0 -17.2,-7.71312 -17.2,-17.2c0,-9.48687 7.71313,-17.2 17.2,-17.2c9.48688,0 17.2,7.71313 17.2,17.2v-30.96zM34.4,123.84c9.48688,0 17.2,7.71313 17.2,17.2c0,9.48688 -7.71312,17.2 -17.2,17.2c-9.48687,0 -17.2,-7.71312 -17.2,-17.2c0,-9.48687 7.71313,-17.2 17.2,-17.2zM92.88,123.84c9.48688,0 17.2,7.71313 17.2,17.2c0,9.48688 -7.71312,17.2 -17.2,17.2c-9.48687,0 -17.2,-7.71312 -17.2,-17.2c0,-9.48687 7.71313,-17.2 17.2,-17.2zM34.4,130.72c-5.6975,0 -10.32,4.6225 -10.32,10.32c0,5.6975 4.6225,10.32 10.32,10.32c5.6975,0 10.32,-4.6225 10.32,-10.32c0,-5.6975 -4.6225,-10.32 -10.32,-10.32zM92.88,130.72c-5.6975,0 -10.32,4.6225 -10.32,10.32c0,5.6975 4.6225,10.32 10.32,10.32c5.6975,0 10.32,-4.6225 10.32,-10.32c0,-5.6975 -4.6225,-10.32 -10.32,-10.32zM154.8,130.72c-5.6975,0 -10.32,4.6225 -10.32,10.32c0,5.6975 4.6225,10.32 10.32,10.32c5.6975,0 10.32,-4.6225 10.32,-10.32c0,-5.6975 -4.6225,-10.32 -10.32,-10.32z"></path></g></g></g></svg>
        </a>
        <a class="btn btn-primary">
          <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
            width="50" height="50"
            viewBox="0 0 172 172"
            style=" fill:#000000;"><g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><path d="M0,172v-172h172v172z" fill="none"></path><g fill="#ffffff"><g id="surface1"><path d="M20.64,6.88c-3.7625,0 -6.88,3.1175 -6.88,6.88v7.51156c-3.99094,1.42437 -6.88,5.21375 -6.88,9.68844v123.84c0,5.68406 4.63594,10.32 10.32,10.32h92.88v-144.48h-20.64v-6.88h20.64v6.88h6.88v-6.88h17.2v6.88h6.88v-6.88h10.32v6.88h-10.32v144.48h13.76c5.68406,0 10.32,-4.63594 10.32,-10.32v-123.84c0,-4.47469 -2.88906,-8.26406 -6.88,-9.68844v-7.51156c0,-3.7625 -3.1175,-6.88 -6.88,-6.88zM134.16,20.64h-17.2v144.48h17.2v-6.88h-13.76v-6.88h13.76v-6.88h-13.76v-6.88h13.76v-6.88h-13.76v-6.88h13.76v-6.88h-13.76v-6.88h13.76v-6.88h-13.76v-6.88h13.76v-6.88h-13.76v-6.88h13.76v-6.88h-13.76v-6.88h13.76v-6.88h-13.76v-6.88h13.76v-6.88h-13.76v-6.88h13.76v-6.88h-13.76v-6.88h13.76zM20.64,13.76h10.32v6.88h-10.32zM37.84,13.76h17.2v6.88h-17.2zM61.92,13.76h20.64v6.88h-20.64z"></path></g></g></g></svg>
        </a>
        <a class="btn btn-primary">
          <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
            width="50" height="50"
            viewBox="0 0 172 172"
            style=" fill:#000000;"><g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><path d="M0,172v-172h172v172z" fill="none"></path><g fill="#ffffff"><path d="M52.28531,17.2c-1.204,0 -2.33705,0.62001 -2.95625,1.68641l-13.45094,22.39359h46.68187v-24.08zM89.44,17.2v24.08h46.68187l-13.45094,-22.39359c-0.6192,-1.0664 -1.75225,-1.68641 -2.95625,-1.68641zM34.4,48.16v99.76c0,1.892 1.548,3.44 3.44,3.44h96.32c1.892,0 3.44,-1.548 3.44,-3.44v-99.76zM154.8,51.6v10.32h-10.32v6.88h10.32v10.32l17.2,-13.76zM3.44,61.92c-1.24059,-0.01754 -2.39452,0.63425 -3.01993,1.7058c-0.62541,1.07155 -0.62541,2.39684 0,3.46839c0.62541,1.07155 1.77935,1.72335 3.01993,1.7058h10.32h3.44h10.32v-6.88h-10.32h-3.44zM68.8,61.92h34.4c1.892,0 3.44,1.548 3.44,3.44c0,1.892 -1.548,3.44 -3.44,3.44h-34.4c-1.892,0 -3.44,-1.548 -3.44,-3.44c0,-1.892 1.548,-3.44 3.44,-3.44zM17.2,113.52l-17.2,13.76l17.2,13.76v-10.32h10.32v-6.88h-10.32zM144.48,123.84v6.88h10.32h3.44h10.32c1.24059,0.01754 2.39452,-0.63425 3.01993,-1.7058c0.62541,-1.07155 0.62541,-2.39684 0,-3.46839c-0.62541,-1.07155 -1.77935,-1.72335 -3.01993,-1.7058h-10.32h-3.44z"></path></g></g></svg>
        </a>
      </div>
    </div>
  </div>
</div>
<div class="section section-about-us">
      <div class="container">
        <div class="row">
          <div class="col-md-8 ml-auto mr-auto">
            <h2 class="title text-center">Our Advantages</h2>
            <div class="description text-justify">
              <div class="row">
                <div class="col-md-1 col-1">
                  <h5 class="text-primary text-right"><i class="now-ui-icons education_atom"></i></h5>
                </div>      
                <div class="col-md-10 col-10">
                  <h5><span class="paragraph">Bulk raw material handling and processing.</span></h5>  
                </div>
              </div>
              <div class="row">
                <div class="col-md-1 col-1">
                  <h5 class="text-primary text-right"><i class="now-ui-icons education_atom"></i></h5>
                </div>      
                <div class="col-md-10 col-10">
                  <h5><span class="paragraph">Unit materials handling.</span></h5>  
                </div>
              </div>
              <div class="row">
                <div class="col-md-1 col-1">
                  <h5 class="text-primary text-right"><i class="now-ui-icons education_atom"></i></h5>
                </div>      
                <div class="col-md-10 col-10">
                  <h5><span class="paragraph">Customer based expanding throughout the world in a variety of industries such as agricultural, computer, electonic, food processing, pharmaceutical, chemical, botting and canning, print finishing and packaging.</span></h5>  
                </div>
              </div>
              <div class="row">
                <div class="col-md-1 col-1">
                  <h5 class="text-primary text-right"><i class="now-ui-icons education_atom"></i></h5>
                </div>      
                <div class="col-md-10 col-10">
                  <h5><span class="paragraph">Over 20 years experience in design, manufacture and supply.</span></h5>  
                </div>
              </div>
              <div class="row">
                <div class="col-md-1 col-1">
                  <h5 class="text-primary text-right"><i class="now-ui-icons education_atom"></i></h5>
                </div>      
                <div class="col-md-10 col-10">
                  <h5><span class="paragraph">Custom design or adding concept based on the customer needs.</span></h5>  
                </div>
              </div>
              <div class="row">
                <div class="col-md-1 col-1">
                  <h5 class="text-primary text-right"><i class="now-ui-icons education_atom"></i></h5>
                </div>      
                <div class="col-md-10 col-10">
                  <h5><span class="paragraph">Manufacturing concepts help reduce your cost.</span></h5>  
                </div>
              </div>
          </div>
        </div>
        <div class="separator separator-primary"></div>
        <div class="section-story-overview">
          <div class="row">
            <div class="col-md-6">
              <div class="image-container image-left">
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                  <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class=""></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1" class=""></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="3" class=""></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="4" class=""></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="5" class=""></li>
                  </ol>
                <div class="carousel-inner" role="listbox">
                  <div class="carousel-item">
                    <img class="d-block" src="<?php echo base_url() ?>/assets/img/Conveyor-INdo-teh/CIMG4185.jpg" alt="First slide">
                    <div class="carousel-caption d-none d-md-block">
                      <h5>Conveyor</h5>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <img class="d-block" src="<?php echo base_url() ?>/assets/img/Double Paddle/PA160424.jpg" alt="Second slide">
                    <div class="carousel-caption d-none d-md-block">
                      <h5>Double Paddle</h5>
                    </div>
                  </div>
                  <div class="carousel-item active">
                    <img class="d-block" src="<?php echo base_url() ?>/assets/img/Homogenizer RISTRA/DSCN2943.jpg" alt="Third slide">
                    <div class="carousel-caption d-none d-md-block">
                      <h5>Homogenizer</h5>
                    </div>
                  </div>
                  <div class="carousel-item">
                    <img class="d-block" src="<?php echo base_url() ?>/assets/img/Kneader Mixer/SAM_0105.jpg" alt="Four slide">
                    <div class="carousel-caption d-none d-md-block">
                      <h5>Kneader Mixer</h5>
                    </div>
                  </div>
                   <div class="carousel-item">
                    <img class="d-block" src="<?php echo base_url() ?>/assets/img/Screw Conveyor & Ribbon Mixer/CIMG7404.jpg" alt="Five slide">
                    <div class="carousel-caption d-none d-md-block">
                      <h5>Screw Conveyor</h5>
                    </div>
                  </div>
                   <div class="carousel-item">
                    <img class="d-block" src="<?php echo base_url() ?>/assets/img/Screw Conveyor & Ribbon Mixer/CIMG7407.jpg" alt="Six slide">
                    <div class="carousel-caption d-none d-md-block">
                      <h5>Ribbon Mixer</h5>
                    </div>
                  </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                  <i class="now-ui-icons arrows-1_minimal-left"></i>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                  <i class="now-ui-icons arrows-1_minimal-right"></i>
                </a>
              </div>
            </div>
              <!-- Second image on the left side of the article -->
              <div class="image-container" style="background-image: url('<?php echo base_url() ?>/assets/img/fileuser/conveyorsystem.png');background-repeat:no-repeat; background-size:650px; width: 117%">
              </div>
              <p class="blockquote blockquote-primary">"Our selection of handling components for you"
                  <img src="<?php echo base_url('assets/img/fileuser/ourselection.png'); ?>" alt="">
                  <br>
                  <small>-FBTM</small>
                </p>
            </div>
            <div class="col-md-5 mob">
              <!-- First image on the right side, above the article -->
              <div class="image-container image-right" style="background-color: #012b727d; background-size:650px;">
                <video src="<?php echo base_url() ?>/assets/img/SachetBonding/video.mp4" width="557" height="315" poster="<?php echo base_url('assets/img/fileuser/logonamafajar.png'); ?>" controls></video> 
              </div>
              <h3>Material Handling</h3>
              <p class="text-justfy">
              	Efficient handling and storing of materials are vital to an industry, in order to keep the production flowing smothly, it is important to have an efficient and well thought through flow of production. There are many factors to consider when selecting a conveyor system, it is important to clarify first hand the use of the conveyor system needed  as our product may vary depending
                on the industry's request. 
              </p>
              <p class="text-justfy">
                The following are to consider when choosing a conveyor system : weight and size, loading and pickup points, speed required an well as any additional notes with regards to the items transported. Our company provides an optimal solution for industrial needs.
              </p>
              <p>
              	In today marketplace, many companies face issues of global competition, accelerated innovation and the escalating cost of operating a business. Our company can improve your competitive advantage to achieve your business growth goals.
              </p>
              <p class="text-justfy">
                Whether conveying, sorting, storing or picking and placing, our company is the best choice. In conveyor technology, seamless and integrated productivity is a requirement for success. We delivers flexible and future-oriented solutions tailored to your requirements, economical, precise and eficient.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
    <div class="section section-team text-center">
      <div class="container">
        <h2 class="title">Product category</h2>
        <div class="team">
          <!--Table-->
          <table id="tablePreview" class="table table-striped table-bordered table-responsive">
          <!--Table head-->
            <thead>
              <tr>
                <th>Industry Category</th>
                <th>Conveyor system</th>
                <th>Tangki & Mixer</th>
                <th>Formulasi system</th>
                <th>Customized system</th>
              </tr>
            </thead>
            <!--Table head-->
            <!--Table body-->
            <tbody>
              <tr>
                <td scope="row" class="text-left">Warehouse & Distribution</td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td></td>
                <td></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
              </tr>
              <tr>
                <td scope="row" class="text-left">Last NameWEcommerce / Fulfillment</td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td></td>
                <td></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
              </tr>
              <tr>
                <td scope="row" class="text-left">Pharmaceutical</td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
              </tr>
              <tr>
                <td scope="row" class="text-left">Manufacturing</td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
              </tr>
              <tr>
                <td scope="row" class="text-left">Packaging / Printing</td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td></td>
                <td></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
              </tr>
              <tr>
                <td scope="row" class="text-left">Industrial Products</td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
              </tr>
              <tr>
                <td class="text-left">Clean Rooms / High Risk</td>
                <td></td>
                <td></td>
                <td></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
              </tr>
              <tr>
                <td class="text-left">Logistics Operations</td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td></td>
                <td></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
               </tr>
               <tr> 
                <td class="text-left">Drink</td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
              </tr>
              <tr>
                <td class="text-left">Chemical</td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
              </tr>
              <tr>
                <td class="text-left">Consumer Goods</td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
              </tr>
              <tr>
                <td class="text-left">Retail Products</td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td></td>
                <td></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
              </tr>
              <tr>
                <td class="text-left">Chilled/cold Store Environments</td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td></td>
                <td></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
              </tr>
              <tr>
                <td class="text-left">Agricultural</td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
              </tr>
              <tr>
                <td class="text-left">Construction</td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
                <td></td>
                <td><i class="now-ui-icons ui-1_check"></i></td>
              </tr>
            </tbody>
            <!--Table body-->
          </table>
          <!--Table-->
        </div>
      </div>
    </div>

    <div class="section section-team text-center">
        <div class="container-fluid">
          <h2 class="title">Our partner</h2>
          <div class="team">
          <div class="row">
            <div class="col-md-12">
              <div class="team-player">
                <img src="<?php echo base_url() ?>/assets/img/ourpartner/baygon.png" alt="">
                <img src="<?php echo base_url() ?>/assets/img/ourpartner/cocacola.jpg" alt="">
                <img src="<?php echo base_url() ?>/assets/img/ourpartner/indofod.png" alt="">
                <img src="<?php echo base_url() ?>/assets/img/ourpartner/kimiafarma.png" alt="">
                <img src="<?php echo base_url() ?>/assets/img/ourpartner/kino.png" alt="">
                <img src="<?php echo base_url() ?>/assets/img/ourpartner/ppg.png" alt="">
                <img src="<?php echo base_url() ?>/assets/img/ourpartner/saintgobain.png" alt="">
                <img src="<?php echo base_url() ?>/assets/img/ourpartner/sariroti.png" alt="">
                <img src="<?php echo base_url() ?>/assets/img/ourpartner/phapros.jpg" alt="">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


    <div class="section section-contact-us text-center">
      <div class="container">
        <h2 class="title">Want to work with us?</h2>
        <p class="description">Your project is very important to us</p>
        <div class="row">
          <div class="col-lg-6 text-center col-md-8 ml-auto mr-auto">
            <div class="input-group input-lg">
              <div class="input-group-prepend">
                <span class="input-group-text">
                  <i class="now-ui-icons users_circle-08"></i>
                </span>
              </div>
              <input type="text" name="nama" class="form-control" placeholder="First Name...">
            </div>
            <div class="input-group input-lg">
              <div class="input-group-prepend">
                <span class="input-group-text">
                  <i class="now-ui-icons ui-1_email-85"></i>
                </span>
              </div>
              <input type="text" name="mail" class="form-control" placeholder="Email...">
            </div>
            <div class="textarea-container">
              <textarea class="form-control" name="body" rows="4" cols="80" placeholder="Type a message..."></textarea>
            </div>
            <div class="send-button">
              <button type="submit" onclick="window.location.href='mailto:ariezhujan@gmail.com?subject=$nama&body=$msg'" class="btn btn-primary btn-round btn-block btn-lg">Send Message</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <footer class="page-footer font-small bg-info pt-4">

  <!-- Footer Text -->
  <div class="container text-center text-md-left">

    <!-- Grid row -->
    <div class="row">

      <!-- Grid column -->
      <div class="col-md-6 mt-md-0 mt-3">

        <!-- Content -->
        <h5 class="text-uppercase font-weight-bold">Office</h5>
        <div class="row">
          <div class="col-md-1">
            <img src="https://img.icons8.com/ios-glyphs/24/000000/link-company-parent.png">
          </div>
          <div class="col-md-10">
            <address>Gading Mediterania Residences Ruko 29 H <br> Jl. Boulevard Gading Raya, Kelapa gading Permai, Jakarta Utara 14240, Indonesia </address>
          </div>
        </div>
        <div class="row">
          <div class="col-md-1">
            <img src="https://img.icons8.com/material-two-tone/24/000000/phone.png">
          </div>
          <div class="col-md-10">
            <address>+ 62-21-30042058, + 62-21-33830999</address>
          </div>
        </div>
        <div class="row">
          <div class="col-md-1">
            <img src="https://img.icons8.com/material/24/000000/whatsapp--v1.png">
          </div>
          <div class="col-md-10">
            <address>+ 62-818-0301-4077</address>
          </div>
        </div>
        <div class="row">
          <div class="col-md-1">
            <img src="https://img.icons8.com/material/30/000000/fax.png">
          </div>
          <div class="col-md-10">
            <address>+ 62-21-30042057</address>
          </div>
        </div>
        <div class="row">
          <div class="col-md-1">
            <img src="https://img.icons8.com/material/24/000000/mail-contact.png">
          </div>
          <div class="col-md-10">
            <address>info@fabatech.net</address>
          </div>
        </div>
      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none pb-3">

      <!-- Grid column -->
      <div class="col-md-6 mb-md-0 mb-3">

        <!-- Content -->
        <h5 class="text-uppercase font-weight-bold">Workshop</h5>
        <div class="row">
          <div class="col-md-1">
            <img src="https://img.icons8.com/ios-filled/24/000000/full-tool-storage-box-.png">
          </div>
          <div class="col-md-10">
            <address>Kawasan Industri Candi JL. Gatot Subroto Blok XXVII / 5. Semarang 50188 , Jawa Tengah Indonesia </address>
          </div>
        </div>
        <div class="row">
          <div class="col-md-1">
            <img src="https://img.icons8.com/material-two-tone/24/000000/phone.png">
          </div>
          <div class="col-md-10">
            <address>+ 62-24-7625823 (Hunting)</address>
          </div>
        </div>
        <div class="row">
          <div class="col-md-1">
            <img src="https://img.icons8.com/material/24/000000/whatsapp--v1.png">
          </div>
          <div class="col-md-10">
            <address>+ 62-818-0301-4077</address>
          </div>
        </div>
        <div class="row">
          <div class="col-md-1">
            <img src="https://img.icons8.com/material/30/000000/fax.png">
          </div>
          <div class="col-md-10">
            <address>+ 62-62-24-7625832</address>
          </div>
        </div>
        <div class="row">
          <div class="col-md-1">
            <img src="https://img.icons8.com/material/24/000000/mail-contact.png">
          </div>
          <div class="col-md-10">
            <address>info@fabatech.net</address>
          </div>
        </div>
      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Text -->
</footer>
<!-- Footer -->

    <div class="footer" style="margin-bottom: -30px;margin-top: -30px">
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3959.984425279168!2d110.34789961477345!3d-7.011114194935529!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e708a8dc85b89f7%3A0xcbb2b7a8843b0d6a!2sPT.+Fajar+Baru+Teknik+Makmur!5e0!3m2!1sid!2sid!4v1566199741486!5m2!1sid!2sid" width="100%" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>




    