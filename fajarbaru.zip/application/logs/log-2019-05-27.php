<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-27 09:36:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-27 09:36:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:11 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:11 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:12 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:12 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:12 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:14 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:14 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:14 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:14 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:14 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:14 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:15 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:15 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:15 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:15 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:15 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:15 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:15 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:15 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:15 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:15 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:15 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:16 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:16 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:16 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:16 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:16 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:16 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:16 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:16 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:16 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:16 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:16 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:16 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:16 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:16 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:16 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:16 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:17 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:17 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:17 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:17 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:17 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:17 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:17 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:17 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:17 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:17 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:17 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:17 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:17 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:17 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:17 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:18 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:18 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:20 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:20 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:20 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:20 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:20 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:20 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:21 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:21 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:21 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:21 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:21 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:21 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:21 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:21 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:21 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:21 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:21 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:21 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:21 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:21 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:22 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:22 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:22 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:22 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:22 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:22 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:22 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:22 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:22 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:22 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:22 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:22 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:22 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:22 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:23 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:23 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:23 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:23 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:23 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:23 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:23 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:23 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:23 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:23 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:23 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:23 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:23 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:23 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:24 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:24 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:25 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:25 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:25 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:25 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:25 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:25 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:26 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:26 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:26 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:26 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:26 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:26 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:26 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:26 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:26 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:26 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:26 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:26 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:27 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:27 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:27 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:27 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:27 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:27 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:27 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:27 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:27 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:27 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:27 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:27 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:27 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:28 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:28 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:28 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:28 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:28 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:28 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:28 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:28 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:29 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:29 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:29 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:29 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:29 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:30 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:30 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:30 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:31 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:31 --> Unable to connect to the database
ERROR - 2019-05-27 09:36:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ssd' C:\xampp\htdocs\ssd\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2019-05-27 09:36:31 --> Unable to connect to the database
ERROR - 2019-05-27 13:57:19 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:19 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:19 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:19 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:19 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:19 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:20 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:20 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:20 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:20 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:20 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:20 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:20 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:20 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:20 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:20 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:21 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:21 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:21 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:21 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:21 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:21 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:21 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:21 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:21 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:21 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:21 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:22 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:22 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:22 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:22 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:22 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:22 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:22 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:22 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:22 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:22 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:23 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:23 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:23 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:23 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:23 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:23 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:23 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:23 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:23 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:24 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:24 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:24 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:24 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:24 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:24 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:24 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:24 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:24 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:24 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:24 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:25 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:25 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:25 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:25 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:25 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:25 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:25 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:25 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:25 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:25 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:26 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:26 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:26 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:26 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:26 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:26 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:26 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:26 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:26 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:26 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:27 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:27 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:27 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:27 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:27 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:27 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:27 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:27 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:27 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:27 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:28 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:28 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:28 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:28 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:28 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:28 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:28 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:28 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:28 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:28 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:29 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:29 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:29 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:29 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:29 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:29 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:29 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:29 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:29 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:29 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:30 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:30 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:30 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:30 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:30 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:30 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:30 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:30 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:30 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:30 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:31 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:31 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:31 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:31 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:31 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:31 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:31 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:31 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:31 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:32 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:32 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:32 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:32 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:32 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:32 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:32 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:32 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:33 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:33 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:33 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:33 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:33 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:33 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:33 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:33 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:33 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:34 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:34 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:34 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:34 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:34 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:34 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
ERROR - 2019-05-27 13:57:34 --> Severity: error --> Exception: Too few arguments to function Cell::index(), 1 passed in C:\xampp\htdocs\ssd\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\ssd\application\controllers\Cell.php 6
