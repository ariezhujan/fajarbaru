<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-16 15:15:21 --> 404 Page Not Found: Conveyorphp/index
ERROR - 2019-08-16 15:15:32 --> 404 Page Not Found: Conveyorphp/index
ERROR - 2019-08-16 15:20:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-16 15:20:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-16 15:44:09 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-16 15:44:09 --> 404 Page Not Found: Assets/css
