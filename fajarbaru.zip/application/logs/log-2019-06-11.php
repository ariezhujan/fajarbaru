<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-11 12:13:32 --> Severity: error --> Exception: syntax error, unexpected '{' C:\xampp\htdocs\ssd\application\controllers\Json.php 18
ERROR - 2019-06-11 12:13:42 --> Severity: error --> Exception: syntax error, unexpected '{' C:\xampp\htdocs\ssd\application\controllers\Json.php 18
