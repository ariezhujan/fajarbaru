<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-29 17:06:57 --> 404 Page Not Found: Json/1
ERROR - 2019-05-29 17:08:13 --> 404 Page Not Found: Json/1
