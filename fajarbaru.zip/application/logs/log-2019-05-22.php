<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-22 21:34:16 --> Unable to load the requested class: Auth
ERROR - 2019-05-22 21:34:17 --> Unable to load the requested class: Auth
