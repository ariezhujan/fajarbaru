<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-03 14:42:35 --> 404 Page Not Found: Wp-admin/index
