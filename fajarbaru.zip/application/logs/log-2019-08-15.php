<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-15 12:24:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-15 12:24:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-15 13:28:10 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-15 13:28:10 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-15 13:30:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-15 13:30:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-15 13:30:56 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-15 13:44:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-15 13:44:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-15 13:44:48 --> Severity: Notice --> Undefined variable: content C:\xampp\htdocs\fajarteknik\application\views\master.php 122
ERROR - 2019-08-15 13:44:56 --> Severity: Notice --> Undefined variable: content C:\xampp\htdocs\fajarteknik\application\views\master.php 122
ERROR - 2019-08-15 15:57:11 --> Severity: Notice --> Undefined variable: content C:\xampp\htdocs\fajarteknik\application\views\master.php 122
