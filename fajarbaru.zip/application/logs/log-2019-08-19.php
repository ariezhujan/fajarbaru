<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-19 00:14:15 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 00:14:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 00:15:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 00:15:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 00:15:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 00:15:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 00:19:06 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 00:19:07 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 00:23:02 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 00:23:03 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 00:24:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 00:24:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 01:59:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 01:59:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 02:00:22 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 02:00:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 08:23:16 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 08:39:36 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 08:50:26 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 08:50:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 10:04:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 10:04:13 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 10:04:19 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 10:18:38 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 11:08:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 11:08:27 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 11:12:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 11:12:13 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 11:43:49 --> Severity: error --> Exception: Too few arguments to function Home::massage(), 0 passed in C:\xampp\htdocs\fajarteknik\system\core\CodeIgniter.php on line 532 and exactly 3 expected C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 10
ERROR - 2019-08-19 11:44:11 --> Severity: error --> Exception: Too few arguments to function Home::massage(), 0 passed in C:\xampp\htdocs\fajarteknik\system\core\CodeIgniter.php on line 532 and exactly 3 expected C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 10
ERROR - 2019-08-19 11:57:57 --> Severity: error --> Exception: Too few arguments to function Home::massage(), 1 passed in C:\xampp\htdocs\fajarteknik\application\controllers\Home.php on line 9 and exactly 2 expected C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 21
ERROR - 2019-08-19 11:58:16 --> Severity: error --> Exception: Too few arguments to function Home::massage(), 1 passed in C:\xampp\htdocs\fajarteknik\application\controllers\Home.php on line 9 and exactly 2 expected C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 21
ERROR - 2019-08-19 12:03:57 --> Severity: error --> Exception: Too few arguments to function Home::massage(), 0 passed in C:\xampp\htdocs\fajarteknik\system\core\CodeIgniter.php on line 532 and exactly 3 expected C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 16
ERROR - 2019-08-19 12:05:27 --> Severity: error --> Exception: Too few arguments to function Home::massage(), 0 passed in C:\xampp\htdocs\fajarteknik\system\core\CodeIgniter.php on line 532 and exactly 3 expected C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 16
ERROR - 2019-08-19 12:06:05 --> Severity: error --> Exception: Too few arguments to function Home::massage(), 0 passed in C:\xampp\htdocs\fajarteknik\system\core\CodeIgniter.php on line 532 and exactly 3 expected C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 16
ERROR - 2019-08-19 12:21:32 --> Severity: error --> Exception: Too few arguments to function Home::massage(), 0 passed in C:\xampp\htdocs\fajarteknik\system\core\CodeIgniter.php on line 532 and exactly 3 expected C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 16
ERROR - 2019-08-19 12:22:02 --> Severity: error --> Exception: syntax error, unexpected '"', expecting variable (T_VARIABLE) C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 16
ERROR - 2019-08-19 12:22:19 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 16
ERROR - 2019-08-19 12:22:50 --> Severity: error --> Exception: Too few arguments to function Home::massage(), 0 passed in C:\xampp\htdocs\fajarteknik\system\core\CodeIgniter.php on line 532 and exactly 3 expected C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 16
ERROR - 2019-08-19 12:25:36 --> Severity: error --> Exception: Too few arguments to function Home::massage(), 0 passed in C:\xampp\htdocs\fajarteknik\system\core\CodeIgniter.php on line 532 and exactly 3 expected C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 16
ERROR - 2019-08-19 12:26:26 --> Severity: error --> Exception: Too few arguments to function Home::massage(), 0 passed in C:\xampp\htdocs\fajarteknik\system\core\CodeIgniter.php on line 532 and exactly 3 expected C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 16
ERROR - 2019-08-19 12:27:36 --> Severity: error --> Exception: Too few arguments to function Home::massage(), 0 passed in C:\xampp\htdocs\fajarteknik\system\core\CodeIgniter.php on line 532 and exactly 3 expected C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 16
ERROR - 2019-08-19 12:27:47 --> Severity: error --> Exception: Too few arguments to function Home::massage(), 0 passed in C:\xampp\htdocs\fajarteknik\system\core\CodeIgniter.php on line 532 and exactly 3 expected C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 16
ERROR - 2019-08-19 12:40:41 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 19
ERROR - 2019-08-19 12:40:58 --> Severity: Notice --> Undefined variable: post1 C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 19
ERROR - 2019-08-19 12:41:14 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 19
ERROR - 2019-08-19 12:41:28 --> Severity: error --> Exception: Function name must be a string C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 19
ERROR - 2019-08-19 12:43:29 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 21
ERROR - 2019-08-19 12:43:37 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 21
ERROR - 2019-08-19 12:43:53 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 21
ERROR - 2019-08-19 12:43:59 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 20
ERROR - 2019-08-19 12:43:59 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 20
ERROR - 2019-08-19 12:43:59 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 20
ERROR - 2019-08-19 12:44:42 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 20
ERROR - 2019-08-19 12:44:42 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 20
ERROR - 2019-08-19 12:44:42 --> Severity: Notice --> Trying to get property 'nama' of non-object C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 20
ERROR - 2019-08-19 12:47:19 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 19
ERROR - 2019-08-19 12:48:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 19
ERROR - 2019-08-19 12:48:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 19
ERROR - 2019-08-19 12:49:45 --> Severity: Notice --> Undefined variable: body C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 22
ERROR - 2019-08-19 13:11:29 --> Severity: error --> Exception: Call to undefined method Home::mail() C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 23
ERROR - 2019-08-19 13:13:27 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 23
ERROR - 2019-08-19 13:13:28 --> 404 Page Not Found: Index/index
ERROR - 2019-08-19 13:13:53 --> 404 Page Not Found: Index/index
ERROR - 2019-08-19 13:13:56 --> 404 Page Not Found: Index/index
ERROR - 2019-08-19 13:15:17 --> Severity: error --> Exception: Call to undefined method Home::mail() C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 23
ERROR - 2019-08-19 13:15:34 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\fajarteknik\application\controllers\Home.php 23
ERROR - 2019-08-19 14:37:43 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 14:37:49 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 14:37:51 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 14:44:23 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 14:44:23 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 14:44:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 14:44:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 14:46:12 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 14:54:31 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 14:54:31 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 14:54:46 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 14:54:46 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 14:55:04 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 14:55:04 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:00:33 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:00:33 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:00:33 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:00:33 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:05:15 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:05:15 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:05:15 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:05:15 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:05:15 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:05:57 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:05:57 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:05:57 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:05:57 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:05:57 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:06:11 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:06:11 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:06:11 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:06:11 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:06:11 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:06:40 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:06:40 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:06:40 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:06:40 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:06:41 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:10:22 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:10:22 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:10:23 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:10:23 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:10:23 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:18:37 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:18:37 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:18:37 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:18:38 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:18:38 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:20:07 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:20:07 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:20:07 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:20:07 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:20:07 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:23:43 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:23:43 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:23:43 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:36:55 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:36:56 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:36:56 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:37:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 15:37:56 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 15:39:15 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:39:15 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:39:15 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:39:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 15:39:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 15:39:46 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:39:46 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:39:46 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:39:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 15:39:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 15:41:12 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:41:12 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:41:12 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:41:12 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 15:41:12 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 15:54:54 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:54:54 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:54:54 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:54:55 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 15:54:55 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 15:55:30 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:55:30 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:55:30 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:55:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 15:55:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 15:56:36 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:56:36 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:56:36 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:56:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 15:56:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 15:57:57 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:57:57 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:57:57 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:57:58 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 15:57:58 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 15:59:00 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:59:00 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:59:00 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:59:01 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 15:59:01 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 15:59:31 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:59:31 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:59:32 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 15:59:32 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 15:59:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 16:01:10 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 16:01:10 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 16:01:10 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 16:01:11 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 16:01:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 16:06:31 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 16:06:31 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 16:06:31 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 16:06:31 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 16:06:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 16:06:53 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 16:06:53 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 16:06:53 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 16:06:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 16:06:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 16:11:00 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 16:11:00 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 16:11:00 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 16:16:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 16:16:51 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 16:19:48 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 16:19:48 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 16:38:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 16:38:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 16:47:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 16:47:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 16:47:53 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 16:47:54 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 16:49:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 16:49:25 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 16:49:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 16:49:39 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 17:01:12 --> 404 Page Not Found: Tanki_mixer/index
ERROR - 2019-08-19 17:04:54 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 17:06:30 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 17:06:41 --> 404 Page Not Found: Assets/fileuser
ERROR - 2019-08-19 19:19:46 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 20:03:42 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 20:03:42 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 20:03:42 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 20:03:42 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 20:03:42 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 20:03:42 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 20:06:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 20:06:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 20:06:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 20:06:52 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 20:11:49 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 20:11:49 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 21:30:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 21:34:36 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 21:34:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 21:48:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 21:48:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 21:50:40 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 21:50:41 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 21:52:17 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 21:52:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 21:53:16 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 21:53:16 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 21:54:44 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 21:54:44 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 21:56:47 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 21:56:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 21:57:28 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 21:57:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 21:57:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 21:57:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 21:58:00 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 21:58:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 22:06:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 22:06:25 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 22:07:26 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 22:07:27 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 22:07:42 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 22:07:42 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 22:09:24 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 22:09:24 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 22:10:38 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 22:10:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 22:11:33 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 22:11:33 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 22:13:57 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 22:13:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 22:17:46 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 22:17:46 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 22:19:20 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 22:19:20 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 22:23:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 22:23:22 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 22:24:43 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 22:24:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 22:27:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 22:27:04 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 22:27:23 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 22:27:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 22:43:30 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 22:43:30 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 23:29:09 --> 404 Page Not Found: Assets/js
ERROR - 2019-08-19 23:29:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 23:29:13 --> 404 Page Not Found: Assets/img
